package org.quiltmc.launchermeta.version.v1;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;
import org.quiltmc.launchermeta.version_manifest.VersionManifest;
import org.quiltmc.launchermeta.version_manifest.VersionManifestTest;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class VersionTest {
    private static final String VERSION_URL = "https://launchermeta.mojang.com/v1/packages/f2affa3247f2471d3334b199d1915ce582914464/21w42a.json";

    private static <T> List<Method> getAllGetterMethodsWithReturnInPackage(Class<T> clazz) {
        Method[] methods = clazz.getMethods();

        return Arrays.stream(methods)
                .filter(method -> method.getParameterCount() == 0)
                .filter(method -> !method.getDeclaringClass().equals(Object.class))
                .collect(Collectors.toList());
    }

    @Test
    public void testParseFullJson() throws IOException {
        JsonElement json = JsonParser.parseString(new String(new URL(VERSION_URL).openStream().readAllBytes()));
        assertDoesNotThrow(() -> {
            Version version = Version.fromJson(json);
        });
    }

    @Test
    public void assertNoMethodReturnsAreNull() throws IOException {
        VersionManifest.fromJson(JsonParser.parseString(new String(new URL(VersionManifestTest.MANIFEST_URL).openStream().readAllBytes())))
                .getVersions()
                .parallelStream()
                .map(version -> {
                    JsonElement json = null;
                    try {
                        json = JsonParser.parseString(new String(new URL(version.getUrl()).openStream().readAllBytes()));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    return Version.fromJson(json);
                }).forEach(version -> {
            Map<Object, List<Method>> getters = Map.of(version, getAllGetterMethodsWithReturnInPackage(Version.class));

            while (!getters.isEmpty()) {
                Map<Object, List<Method>> newGetters = new HashMap<>();
                for (Object invoke : getters.keySet()) {
                    List<Method> methods = getters.get(invoke);
                    for (Method method : methods) {
                        try {
                            Object result = method.invoke(invoke);
                            assertNotNull(result, "Method " + method.getName() + " returned null with version " + version.getId());
                            if (result.getClass().getPackageName().startsWith("org.quiltmc")) {
                                newGetters.put(result, getAllGetterMethodsWithReturnInPackage(result.getClass()));
                            } else if (result instanceof Optional<?> o && o.isPresent() && o.get().getClass().getPackageName().startsWith("org.quiltmc")) {
                                newGetters.put(o.get(), getAllGetterMethodsWithReturnInPackage(o.get().getClass()));
                            }
                        } catch (IllegalAccessException | InvocationTargetException e) {
                            e.printStackTrace();
                        }
                    }
                }
                getters = newGetters;
            }
        });
    }
}