package org.quiltmc.launchermeta.version_manifest;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class VersionManifestTest {
    public static final String MANIFEST_URL = "https://launchermeta.mojang.com/mc/game/version_manifest.json";

    private static final String TEST_JSON = """
            {
                "latest": {
                    "release": "1.17.1",
                    "snapshot": "21w42a"
                },
                "versions": [{
                    "id": "21w42a",
                    "type": "snapshot",
                    "url": "https://launchermeta.mojang.com/v1/packages/f2affa3247f2471d3334b199d1915ce582914464/21w42a.json",
                    "time": "2021-10-20T12:46:24+00:00",
                    "releaseTime": "2021-10-20T12:41:25+00:00"
                }]
            }
            """;

    private static final Gson GSON = new Gson();

    private static <T> List<Method> getAllGetterMethodsWithReturnInPackage(Class<T> clazz) {
        Method[] methods = clazz.getMethods();

        return Arrays.stream(methods)
                .filter(method -> method.getParameterCount() == 0)
                .filter(method -> !method.getDeclaringClass().equals(Object.class))
                .collect(Collectors.toList());
    }

    @Test
    public void testParseFullJson() throws IOException {
        JsonElement json = JsonParser.parseString(new String(new URL(MANIFEST_URL).openStream().readAllBytes()));
        VersionManifest manifest = VersionManifest.fromJson(json);

        assertEquals(manifest.getVersions().size(), json.getAsJsonObject().get("versions").getAsJsonArray().size(), "Size of version array matches json");
        assertEquals(manifest.getLatestVersions().getRelease(), json.getAsJsonObject().get("latest").getAsJsonObject().get("release").getAsString(), "Size of version array matches json");
    }

    @Test
    public void testParseTestJson() {
        VersionManifest actual = GSON.fromJson(TEST_JSON, VersionManifest.class);
        VersionManifest expected = new VersionManifest(new LatestVersions("1.17.1", "21w42a"),
                List.of(new Version("21w42a", "snapshot", "https://launchermeta.mojang.com/v1/packages/f2affa3247f2471d3334b199d1915ce582914464/21w42a.json", "2021-10-20T12:46:24+00:00", "2021-10-20T12:41:25+00:00")));

        assertEquals(actual, expected, "Actual parse matches expected result");
    }

    @Test
    public void assertNoMethodReturnsAreNull() throws IOException {
        VersionManifest.fromJson(JsonParser.parseString(new String(new URL(VersionManifestTest.MANIFEST_URL).openStream().readAllBytes())))
                .getVersions().parallelStream().forEach(version -> {
            Map<Object, List<Method>> getters = Map.of(version, getAllGetterMethodsWithReturnInPackage(Version.class));

            while (!getters.isEmpty()) {
                Map<Object, List<Method>> newGetters = new HashMap<>();
                for (Object invoke : getters.keySet()) {
                    List<Method> methods = getters.get(invoke);
                    for (Method method : methods) {
                        try {
                            Object result = method.invoke(invoke);
                            assertNotNull(result, "Method " + method.getName() + " returned null with version " + version.getId());
                            if (result.getClass().getPackageName().startsWith("org.quiltmc")) {
                                newGetters.put(result, getAllGetterMethodsWithReturnInPackage(result.getClass()));
                            } else if (result instanceof Optional<?> o && o.isPresent() && o.get().getClass().getPackageName().startsWith("org.quiltmc")) {
                                newGetters.put(o.get(), getAllGetterMethodsWithReturnInPackage(o.get().getClass()));
                            }
                        } catch (IllegalAccessException | InvocationTargetException e) {
                            e.printStackTrace();
                        }
                    }
                }
                getters = newGetters;
            }
        });
    }
}