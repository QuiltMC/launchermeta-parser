package org.quiltmc.launchermeta.version.v1;

import java.util.Objects;

public class Logging {
    private final LoggingInstance client;

    public Logging(LoggingInstance client) {
        this.client = client;
    }

    public LoggingInstance getClient() {
        return client;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Logging logging = (Logging) o;
        return Objects.equals(client, logging.client);
    }

    public static class LoggingInstance {
        private final String argument;
        private final String type;
        private final Download.IdDownload file;

        public LoggingInstance(String argument, String type, Download.IdDownload file) {
            this.argument = argument;
            this.type = type;
            this.file = file;
        }

        public String getArgument() {
            return argument;
        }

        public String getType() {
            return type;
        }

        public Download.IdDownload getFile() {
            return file;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            LoggingInstance that = (LoggingInstance) o;
            return Objects.equals(argument, that.argument) && Objects.equals(type, that.type) && Objects.equals(file, that.file);
        }
    }
}
