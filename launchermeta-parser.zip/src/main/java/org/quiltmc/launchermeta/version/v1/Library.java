package org.quiltmc.launchermeta.version.v1;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.google.gson.annotations.SerializedName;
import org.jetbrains.annotations.Nullable;

public class Library {
    private final Downloads downloads;
    private final String name;
    @Nullable
    private final Natives natives;
    @Nullable
    private final Extract extract;
    private List<Rule> rules = Collections.emptyList();

    public Library(Downloads downloads, String name, @Nullable Natives natives, @Nullable Extract extract, List<Rule> rules) {
        this.downloads = downloads;
        this.name = name;
        this.natives = natives;
        this.extract = extract;
        this.rules = rules;
    }

    public Downloads getDownloads() {
        return downloads;
    }

    public String getName() {
        return name;
    }

    public Optional<Natives> getNatives() {
        return Optional.ofNullable(natives);
    }

    public Optional<Extract> getExtract() {
        return Optional.ofNullable(extract);
    }

    public List<Rule> getRules() {
        return rules;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Library library = (Library) o;
        return downloads.equals(library.downloads) && name.equals(library.name) && Objects.equals(natives, library.natives) && Objects.equals(extract, library.extract) && rules.equals(library.rules);
    }

    public static class Rule {
        private final String action;
        @Nullable
        private final OS os;
        @Nullable
        private final Features features;

        public Rule(String action, @Nullable OS os, @Nullable Features features) {
            this.action = action;
            this.os = os;
            this.features = features;
        }

        public String getAction() {
            return action;
        }

        public Optional<OS> getOs() {
            return Optional.ofNullable(os);
        }

        public Optional<Features> getFeatures() {
            return Optional.ofNullable(features);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Rule rule = (Rule) o;
            return Objects.equals(action, rule.action) && Objects.equals(os, rule.os) && Objects.equals(features, rule.features);
        }

        public static class OS {
            @Nullable
            private final String name;
            @Nullable
            private final String version;
            @Nullable
            private final String arch;

            public OS(@Nullable String name, @Nullable String version, @Nullable String arch) {
                this.name = name;
                this.version = version;
                this.arch = arch;
            }

            public Optional<String> getName() {
                return Optional.ofNullable(name);
            }

            public Optional<String> getVersion() {
                return Optional.ofNullable(version);
            }

            public Optional<String> getArch() {
                return Optional.ofNullable(arch);
            }

            @Override
            public boolean equals(Object o) {
                if (this == o) return true;
                if (o == null || getClass() != o.getClass()) return false;
                OS os = (OS) o;
                return Objects.equals(name, os.name) && Objects.equals(version, os.version) && Objects.equals(arch, os.arch);
            }
        }

        public static class Features {
            @SerializedName("is_demo_user")
            @Nullable
            private Boolean isDemoUser = null;

            @SerializedName("has_custom_resolution")
            @Nullable
            private Boolean hasCustomResolution = null;

            public Features(@Nullable Boolean isDemoUser, @Nullable Boolean hasCustomResolution) {
                this.isDemoUser = isDemoUser;
                this.hasCustomResolution = hasCustomResolution;
            }

            public Optional<Boolean> getDemoUser() {
                return Optional.ofNullable(isDemoUser);
            }

            public Optional<Boolean> getHasCustomResolution() {
                return Optional.ofNullable(hasCustomResolution);
            }

            @Override
            public boolean equals(Object o) {
                if (this == o) return true;
                if (o == null || getClass() != o.getClass()) return false;
                Features features = (Features) o;
                return Objects.equals(isDemoUser, features.isDemoUser) && Objects.equals(hasCustomResolution, features.hasCustomResolution);
            }
        }
    }

    public static class Classifiers {
        @Nullable
        private final Download.PathDownload javadoc;

        @SerializedName("natives-linux")
        @Nullable
        private final Download.PathDownload nativesLinux;

        @SerializedName("natives-macos")
        @Nullable
        private final Download.PathDownload nativesMacOS;

        @SerializedName("natives-osx")
        @Nullable
        private final Download.PathDownload nativesOSX;

        @SerializedName("natives-windows")
        @Nullable
        private final Download.PathDownload nativesWindows;

        @Nullable
        private final Download.PathDownload sources;

        public Classifiers(@Nullable Download.PathDownload javadoc, @Nullable Download.PathDownload nativesLinux, @Nullable Download.PathDownload nativesMacOS, Download.@Nullable PathDownload nativesOSX, @Nullable Download.PathDownload nativesWindows, @Nullable Download.PathDownload sources) {
            this.javadoc = javadoc;
            this.nativesLinux = nativesLinux;
            this.nativesMacOS = nativesMacOS;
            this.nativesOSX = nativesOSX;
            this.nativesWindows = nativesWindows;
            this.sources = sources;
        }

        public Optional<Download.PathDownload> getJavadoc() {
            return Optional.ofNullable(javadoc);
        }

        public Optional<Download.PathDownload> getNativesLinux() {
            return Optional.ofNullable(nativesLinux);
        }

        public Optional<Download.PathDownload> getNativesMacOS() {
            return Optional.ofNullable(nativesMacOS);
        }

        public Optional<Download.PathDownload> getNativesOSX() {
            return Optional.ofNullable(nativesOSX);
        }

        public Optional<Download.PathDownload> getNativesWindows() {
            return Optional.ofNullable(nativesWindows);
        }

        public Optional<Download.PathDownload> getSources() {
            return Optional.ofNullable(sources);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Classifiers that = (Classifiers) o;
            return Objects.equals(javadoc, that.javadoc) && Objects.equals(nativesLinux, that.nativesLinux) && Objects.equals(nativesMacOS, that.nativesMacOS) && Objects.equals(nativesOSX, that.nativesOSX) && Objects.equals(nativesWindows, that.nativesWindows) && Objects.equals(sources, that.sources);
        }
    }

    public static class Natives {
        @Nullable
        private final String osx;
        @Nullable
        private final String linux;
        @Nullable
        private final String windows;

        public Natives(@Nullable String osx, @Nullable String linux, @Nullable String windows) {
            this.osx = osx;
            this.linux = linux;
            this.windows = windows;
        }

        public Optional<String> getOsx() {
            return Optional.ofNullable(osx);
        }

        public Optional<String> getLinux() {
            return Optional.ofNullable(linux);
        }

        public Optional<String> getWindows() {
            return Optional.ofNullable(windows);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Natives natives = (Natives) o;
            return Objects.equals(osx, natives.osx) && Objects.equals(linux, natives.linux) && Objects.equals(windows, natives.windows);
        }
    }

    public static class Extract {
        private List<String> exclude = Collections.emptyList();

        public Extract(List<String> exclude) {
            this.exclude = exclude;
        }

        public List<String> getExclude() {
            return exclude;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Extract extract = (Extract) o;
            return Objects.equals(exclude, extract.exclude);
        }
    }

    public static class Downloads {
        private final Download.PathDownload artifact;
        @Nullable
        private final Classifiers classifiers;

        public Downloads(Download.PathDownload artifact, @Nullable Classifiers classifiers) {
            this.artifact = artifact;
            this.classifiers = classifiers;
        }

        public Download.PathDownload getArtifact() {
            return artifact;
        }

        public Optional<Classifiers> getClassifiers() {
            return Optional.ofNullable(classifiers);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Downloads downloads = (Downloads) o;
            return Objects.equals(artifact, downloads.artifact) && Objects.equals(classifiers, downloads.classifiers);
        }
    }
}
