package org.quiltmc.launchermeta.version.v1;

import java.util.Objects;
import java.util.Optional;

import com.google.gson.annotations.SerializedName;
import org.jetbrains.annotations.Nullable;

public class Downloads {
    private final Download client;
    @SerializedName("client_mappings")
    @Nullable
    private final Download clientMappings;
    @Nullable
    private final Download server;
    @SerializedName("server_mappings")
    @Nullable
    private final Download serverMappings;

    public Downloads(Download client, @Nullable Download clientMappings, @Nullable Download server, @Nullable Download serverMappings) {
        this.client = client;
        this.clientMappings = clientMappings;
        this.server = server;
        this.serverMappings = serverMappings;
    }

    public Download getClient() {
        return client;
    }

    public Optional<Download> getClientMappings() {
        return Optional.ofNullable(clientMappings);
    }

    public Optional<Download> getServer() {
        return Optional.ofNullable(server);
    }

    public Optional<Download> getServerMappings() {
        return Optional.ofNullable(serverMappings);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Downloads downloads = (Downloads) o;
        return Objects.equals(client, downloads.client) && Objects.equals(clientMappings, downloads.clientMappings) && Objects.equals(server, downloads.server) && Objects.equals(serverMappings, downloads.serverMappings);
    }
}
