package org.quiltmc.launchermeta.version.v1;

import java.util.Objects;
import java.util.Optional;

import org.jetbrains.annotations.Nullable;

public class JavaVersion {
    @Nullable
    private final String component;
    private final int majorVersion;

    public JavaVersion(@Nullable String component, int majorVersion) {
        this.component = component;
        this.majorVersion = majorVersion;
    }

    public Optional<String> getComponent() {
        return Optional.ofNullable(component);
    }

    public int getMajorVersion() {
        return majorVersion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        JavaVersion that = (JavaVersion) o;
        return majorVersion == that.majorVersion && Objects.equals(component, that.component);
    }
}
