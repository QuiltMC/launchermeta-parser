package org.quiltmc.launchermeta.version.v1;

public class AssetIndex extends Download.IdDownload {
    private final int totalSize;

    public AssetIndex(String sha1, int size, String url, String id, int totalSize) {
        super(sha1, size, url, id);
        this.totalSize = totalSize;
    }

    public int getTotalSize() {
        return totalSize;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        AssetIndex that = (AssetIndex) o;
        return totalSize == that.totalSize;
    }
}
