package org.quiltmc.launchermeta.version_manifest;

public class Version {
    private final String id;
    private final String type;
    private final String url;
    private final String time;
    private final String releaseTime;

    public Version(String id, String type, String url, String time, String releaseTime) {
        this.id = id;
        this.type = type;
        this.url = url;
        this.time = time;
        this.releaseTime = releaseTime;
    }

    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getUrl() {
        return url;
    }

    public String getTime() {
        return time;
    }

    public String getReleaseTime() {
        return releaseTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Version version = (Version) o;
        return id.equals(version.id) && type.equals(version.type) && url.equals(version.url) && time.equals(version.time) && releaseTime.equals(version.releaseTime);
    }
}
