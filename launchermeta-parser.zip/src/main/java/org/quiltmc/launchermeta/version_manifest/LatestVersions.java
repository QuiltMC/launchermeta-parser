package org.quiltmc.launchermeta.version_manifest;

public class LatestVersions {
    private final String release;
    private final String snapshot;

    public LatestVersions(String release, String snapshot) {
        this.release = release;
        this.snapshot = snapshot;
    }

    public String getRelease() {
        return release;
    }

    public String getSnapshot() {
        return snapshot;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LatestVersions that = (LatestVersions) o;
        return release.equals(that.release) && snapshot.equals(that.snapshot);
    }
}
