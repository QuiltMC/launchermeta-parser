package org.quiltmc.launchermeta.version_manifest;

import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;

public class VersionManifest {
    private static final Gson GSON = new Gson();

    @SerializedName("latest")
    private final LatestVersions latestVersions;

    @SerializedName("versions")
    private final List<Version> versions;

    public VersionManifest(LatestVersions latestVersions, List<Version> versions) {
        this.latestVersions = latestVersions;
        this.versions = versions;
    }

    public static VersionManifest fromJson(JsonElement json) {
        return GSON.fromJson(json, VersionManifest.class);
    }

    public static VersionManifest fromString(String json) {
        return GSON.fromJson(json, VersionManifest.class);
    }

    public LatestVersions getLatestVersions() {
        return latestVersions;
    }

    public List<Version> getVersions() {
        return versions;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VersionManifest manifest = (VersionManifest) o;
        return latestVersions.equals(manifest.latestVersions) && versions.equals(manifest.versions);
    }
}
